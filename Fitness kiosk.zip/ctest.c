#include "fitness.h"
int main(){
recv_pckt();
//send_pckt(0,0,0,0);
printf("bpm: %f\n",bpm());
printf("BMI: %f\n",bmi());
printf("Height: %f\n",height());
printf("Weight: %f\n",weight());
return 0;
}

